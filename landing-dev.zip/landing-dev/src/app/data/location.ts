export const location = [
	{ name: 'ВАО' },
	{ name: 'ЗАО' },
	{ name: 'ЗелАО' },
	{ name: 'НАО' },
	{ name: 'САО' },
	{ name: 'СВАО' },
	{ name: 'СЗАО' },
	{ name: 'ТАО' },
	{ name: 'ЦАО' },
	{ name: 'ЮАО' },
	{ name: 'ЮВАО' },
	{ name: 'ЮЗАО' },
]













