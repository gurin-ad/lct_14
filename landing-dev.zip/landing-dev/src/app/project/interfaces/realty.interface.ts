export interface IRealty {
	name: string;
	type: string;
	location: string;
	square: number;
	price: number;
}