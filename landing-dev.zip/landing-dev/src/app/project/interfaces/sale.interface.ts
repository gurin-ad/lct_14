export interface ISales {
	name: string;
	clients_type: string;
	sales_duration: number;
	sales_volume: number;
	annual_sales_growth: number;
	price: number;
	annual_inflation: number;
}