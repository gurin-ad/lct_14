export interface IEquipment {
	type: string;
	name: string;
	price: number;
}