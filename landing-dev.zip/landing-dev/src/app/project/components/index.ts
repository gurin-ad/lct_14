
export * from './passport/passport.component';
export * from './equipment/equipment.component';
export * from './realty/realty.component';
export * from './sales/sales.component';
export * from './cost/cost.component';
export * from './costs-materals/costs-materals.component';
export * from './costs-rent/costs-rent.component';
export * from './costs-salary/costs-salary.component';
export * from './fixed-costs/fixed-costs.component';
export * from './table/table.component';
export * from './calulation-value/calulation-value.component';
export * from './param/param.component';
export * from './summary/summary.component';
