export interface IHelper {
  id: number;
  field: string;
  page: string;
  text: string;
  topic: number;
}



