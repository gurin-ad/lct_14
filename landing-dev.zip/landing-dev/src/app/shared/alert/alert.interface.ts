export interface IAlert {
  type: string,
  text: string
}
