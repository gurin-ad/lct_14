export interface IOption {
  name: string;
  id?: number;
  active?: boolean;
}
