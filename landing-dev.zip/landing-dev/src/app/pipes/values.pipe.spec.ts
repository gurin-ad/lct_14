import { ValuesPipe } from './values.pipe';

describe('ValuesPipe', () => {
  it('create an instance', () => {
    const pipe = new ValuesPipe();
    expect(pipe).toBeTruthy();
  });
});
