import { FilterByIndexPipe } from './filter-by-index.pipe';

describe('FilterByIndexPipe', () => {
  it('create an instance', () => {
    const pipe = new FilterByIndexPipe();
    expect(pipe).toBeTruthy();
  });
});
