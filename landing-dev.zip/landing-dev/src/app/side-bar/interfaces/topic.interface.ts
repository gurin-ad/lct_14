export interface ITopic {
  id: number;
  name: string;
  category: number;
  examples: string;
  theory: string;
}
