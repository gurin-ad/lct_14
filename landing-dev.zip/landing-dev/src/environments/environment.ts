export const environment = {
  production: false,
  apiUrl: 'https://lct-competition-back.metadoor-invest.com/api/landing',
  apiMainUrl: 'https://dev.api.metadoor-invest.com/api',
	linkMap:'https://datalens.yandex/bw3wgww08pre1',
	authMainApi: 'Token f1bee2870f9df9223d2d84df37584640d51d19c4',
};
